<div class="flex gap-2 p-1 mb-4">
    <div class="flex gap-2 mb-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $messages->unique('user_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button onclick="showUserMessages(<?php echo e($message->user_id); ?>)"
                    class="focus:outline-none">
                <img class="w-[40px] h-[40px] rounded-full border"
                     src="<?php echo e($message->user->profile_image_path); ?>"
                     alt="">
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div id="chat-container"
         class="h-[400px] w-[300px] overflow-y-auto bg-white border rounded p-3 space-y-4">

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $messages->groupBy('group_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupId => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($group->count() > 1): ?>
                
                <div class="rounded-lg p-2 border bg-gray-100 chat-group" data-group-id="<?php echo e($groupId); ?>">
                    <button onclick="copyChatGroup('<?php echo e($groupId); ?>', this)"
                            class="copy-btn p-1 rounded-full hover:bg-green-500/20 transition mb-2"
                            title="کپی پیام‌های این گروه">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#000" viewBox="0 0 24 24">
                            <path d="M16 1H4a2 2 0 0 0-2 2v12h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z"/>
                        </svg>
                    </button>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="message-item hidden mb-2" data-user-id="<?php echo e($message->user_id); ?>">
                            <div class="max-w-[70%] <?php echo e($message->user_id === auth()->id() ? 'ml-auto bg-blue-100' : 'bg-gray-100'); ?> p-2 rounded-lg">
                                <div class="text-sm">
                                    <?php echo e($message->code); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php else: ?>
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="message-item hidden mb-2" data-user-id="<?php echo e($message->user_id); ?>">
                        <div class="max-w-[70%] <?php echo e($message->user_id === auth()->id() ? 'ml-auto bg-blue-100' : 'bg-gray-100'); ?> p-2 rounded-lg">
                            <div class="text-sm">
                                <?php echo e($message->code); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>

    <script>
        function showUserMessages(userId) {
            const messages = document.querySelectorAll('.message-item');
            const container = document.getElementById('chat-container');

            messages.forEach(el => {
                el.classList.add('hidden');
                if (el.dataset.userId == userId) {
                    el.classList.remove('hidden');
                }
            });

            setTimeout(() => {
                container.scrollTop = container.scrollHeight;
            }, 50);
        }

        function copyChatGroup(groupId, btn) {
            let lines = [];

            document.querySelectorAll(`.chat-group[data-group-id="${groupId}"] .message-item`).forEach(el => {
                const text = el.innerText.trim();
                if (text) lines.push(text);
            });

            if (lines.length === 0) return;

            navigator.clipboard.writeText(lines.join('\n'));
            showCopySuccess(btn);
        }


        function showCopySuccess(btn) {
            const svg = btn.querySelector('svg');
            if (!svg) return;

            const oldFill = svg.style.fill;
            svg.style.fill = '#16a34a';

            btn.classList.add('scale-110');

            setTimeout(() => {
                svg.style.fill = oldFill || '#000';
                btn.classList.remove('scale-110');
            }, 2000);
        }


    </script>
</div>
<?php /**PATH C:\Users\10\Downloads\iranyadak_chat-3e1f4bc8d8af9ccf06b30abe423a443096ed6fd9\resources\views\livewire\home\user-chats.blade.php ENDPATH**/ ?>