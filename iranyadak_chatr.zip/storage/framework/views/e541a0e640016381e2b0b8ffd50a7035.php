<div>
    <form wire:submit.prevent="submit" id="chat-box" class="relative">
    <div id="chat-body" class="mb-2">
        <div class="msg bot">.کد محصول مورد نظر را وارد بنمایید</div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($previewUrl): ?>
            <img src="<?php echo e($previewUrl); ?>" style="max-width: 150px; border-radius: 6px; margin-top: 5px;">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div id="chat-input" class="flex gap-2">
        <textarea
            wire:model.defer="test"
            id="messageInput"
            wire:keydown.enter.prevent="submit"
            placeholder="پیام..."
            class="flex-1 border rounded p-1"
        ></textarea>

        
        <input type="file" wire:model="image" class="hidden" id="imageInput">

        
        <button type="button" onclick="document.getElementById('imageInput').click()"
                class="bg-blue-600 text-white px-3 rounded">📎</button>

        <button type="submit" class="bg-green-600 text-white px-3 rounded">➤</button>
    </div>
</form>
<script>
    document.getElementById('messageInput').addEventListener('paste', function(e) {
        const items = (e.clipboardData || e.originalEvent.clipboardData).items;
        for (let index in items) {
            const item = items[index];
            if (item.kind === 'file') {
                const file = item.getAsFile();
            window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('image', file); // Livewire property
            }
        }
    });
</script>
</div>
<?php /**PATH C:\Users\10\Downloads\iranyadak_chat-3e1f4bc8d8af9ccf06b30abe423a443096ed6fd9\resources\views\livewire\chat-with-image.blade.php ENDPATH**/ ?>