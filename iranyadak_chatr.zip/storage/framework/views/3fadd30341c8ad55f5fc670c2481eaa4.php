<div class="bg-gray-200 border-l rounded-b-2xl float-left m-2 w-[24%] max-h-[800px]" style="overflow: auto">
    <div class="bg-blue-600 text-white p-4 rounded-t-2xl font-bold text-center z-10"
         style="position: sticky;top: 0">
        چت‌های در جریان
    </div>

    <ul class="space-y-2 text-sm overflow-scroll">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="p-2 rounded-lg">
                <p class="text-right">
                    کاربر شماره <?php echo e($message->user_id); ?>

                </p>
                <img class="w-[40px] rounded-[100px] inline-block" src="/IMG/prof.jpg" alt="">
                <div id="productCode" class="inline-block">
                    <p class="inline-block">
                        <?php echo e($message->code); ?>

                    </p>
                    <button class="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition"
                            wire:click="code_answer('a',<?php echo e($message->id); ?>)">a
                    </button>
                    <button class="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition"
                            wire:click="code_answer('k',<?php echo e($message->id); ?>)">k
                    </button>
                    <button class="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition"
                            wire:click="code_answer('h',<?php echo e($message->id); ?>)">h
                    </button>
                    <button class="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition"
                            wire:click="code_answer('x',<?php echo e($message->id); ?>)">x
                    </button>
                </div>
                <div class="bg-white"
                     style="margin: 15px 5px 0 5px;padding: 0;border-radius: 10px;height: 40px;overflow: hidden;position:relative;">
                    <input type="text"
                           class="h-[40px] pl-1 w-full bg-white"
                           wire:model.defer="prices.<?php echo e($message->id); ?>"
                           wire:keydown.enter="submit_answer(<?php echo e($message->id); ?>)">
                    <button type="submit"
                            wire:click="submit_answer(<?php echo e($message->id); ?>)"
                            class="inline-block px-4 py-2 bg-blue-600 text-white"
                            style="position:absolute;right: 0;height: 100%">
                        ثبت
                    </button>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </ul>
</div>
<?php /**PATH C:\Users\10\Downloads\iranyadak_chat-3e1f4bc8d8af9ccf06b30abe423a443096ed6fd9\resources\views\livewire\chat-in-progress.blade.php ENDPATH**/ ?>