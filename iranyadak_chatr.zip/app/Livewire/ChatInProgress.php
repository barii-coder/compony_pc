<?php

namespace App\Livewire;

use Livewire\Component;

class ChatInProgress extends Component
{
    public function render()
    {
        return view('livewire.chat-in-progress');
    }
}
